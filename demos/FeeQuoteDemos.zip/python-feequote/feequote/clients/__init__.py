"""Adapters for external systems."""
